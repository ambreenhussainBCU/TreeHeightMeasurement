"""Kivy front end."""
